#include "libavcodec\avcodec.h"
#include "libavcodec\videodsp.h"
#include "libavcodec\me_cmp.h"
#include "libavcodec\h264_mvpred.h"

void ff_videodsp_init_aarch64(VideoDSPContext *ctx, int bpc) {}
void ff_videodsp_init_arm(VideoDSPContext *ctx, int bpc) {}
void ff_videodsp_init_ppc(VideoDSPContext *ctx, int bpc) {}
void ff_videodsp_init_mips(VideoDSPContext *ctx, int bpc) {}
void ff_me_cmp_init_alpha(MECmpContext *c, AVCodecContext *avctx) {}
void ff_me_cmp_init_arm(MECmpContext *c, AVCodecContext *avctx) {}
void ff_me_cmp_init_ppc(MECmpContext *c, AVCodecContext *avctx) {}
void ff_me_cmp_init_mips(MECmpContext *c, AVCodecContext *avctx) {}

void ff_h264qpel_init_aarch64(H264QpelContext *c, int bit_depth) {}
void ff_h264qpel_init_arm(H264QpelContext *c, int bit_depth) {}
void ff_h264qpel_init_ppc(H264QpelContext *c, int bit_depth) {}
void ff_h264qpel_init_mips(H264QpelContext *c, int bit_depth) {}

void ff_h264_pred_init_aarch64(H264PredContext *h, int codec_id,
                               const int bit_depth,
                               const int chroma_format_idc) {}
void ff_h264_pred_init_arm(H264PredContext *h, int codec_id,
                           const int bit_depth, const int chroma_format_idc) {}
void ff_h264_pred_init_mips(H264PredContext *h, int codec_id,
                            const int bit_depth, const int chroma_format_idc) {}

void ff_h264dsp_init_aarch64(H264DSPContext *c, const int bit_depth,
                             const int chroma_format_idc) {}
void ff_h264dsp_init_arm(H264DSPContext *c, const int bit_depth,
                         const int chroma_format_idc) {}
void ff_h264dsp_init_ppc(H264DSPContext *c, const int bit_depth,
                         const int chroma_format_idc) {}
void ff_h264dsp_init_mips(H264DSPContext *c, const int bit_depth,
                          const int chroma_format_idc) {}

void ff_h264chroma_init_aarch64(H264ChromaContext *c, int bit_depth) {}
void ff_h264chroma_init_arm(H264ChromaContext *c, int bit_depth) {}
void ff_h264chroma_init_ppc(H264ChromaContext *c, int bit_depth) {}
void ff_h264chroma_init_mips(H264ChromaContext *c, int bit_depth) {}

void ff_videodsp_init_x86(VideoDSPContext *ctx, int bpc) {}
void ff_me_cmp_init_x86(MECmpContext *c, AVCodecContext *avctx) {}
void ff_h264qpel_init_x86(H264QpelContext *c, int bit_depth) {}
void ff_h264_pred_init_x86(H264PredContext *h, int codec_id,
                           const int bit_depth, const int chroma_format_idc) {}
void ff_h264dsp_init_x86(H264DSPContext *c, const int bit_depth,
                         const int chroma_format_idc) {}
void ff_h264chroma_init_x86(H264ChromaContext *c, int bit_depth) {}

int ff_frame_thread_encoder_init(AVCodecContext *avctx, AVDictionary *options) { return 0;}
void ff_frame_thread_encoder_free(AVCodecContext *avctx) {}
int ff_thread_video_encode_frame(AVCodecContext *avctx, AVPacket *pkt, const AVFrame *frame, int *got_packet_ptr) { return 0; }
