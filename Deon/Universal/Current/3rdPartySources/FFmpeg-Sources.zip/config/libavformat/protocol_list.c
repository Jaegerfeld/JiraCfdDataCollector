static const URLProtocol * const url_protocols[] = {
    &ff_file_protocol,
    NULL };
