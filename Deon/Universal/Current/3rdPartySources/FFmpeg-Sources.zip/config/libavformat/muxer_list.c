static const AVOutputFormat * const muxer_list[] = {
    &ff_mp4_muxer,
    NULL };
