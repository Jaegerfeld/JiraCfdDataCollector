static const AVCodec * const codec_list[] = {
    &ff_h264_decoder,
    NULL };
