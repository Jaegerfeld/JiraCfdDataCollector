static const AVCodecParser * const parser_list[] = {
    NULL };
