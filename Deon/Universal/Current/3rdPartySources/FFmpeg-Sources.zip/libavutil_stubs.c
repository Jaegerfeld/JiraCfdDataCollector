#include "libavcodec\avcodec.h"
#include "libavcodec\videodsp.h"
#include "libavcodec\h264_mvpred.h"
#include "libavutil\random_seed.h"

int ff_get_cpu_flags_aarch64(void) { return -1; }
int ff_get_cpu_flags_arm(void) { return -1; }
int ff_get_cpu_flags_ppc(void) { return -1; }

size_t ff_get_cpu_max_align_aarch64(void) { return 0; }
size_t ff_get_cpu_max_align_arm(void) { return 0; }
size_t ff_get_cpu_max_align_ppc(void) { return 0; }

#if ARCH_X86
int ff_image_copy_plane_uc_from_x86(uint8_t       *dst, ptrdiff_t dst_linesize,
                                    const uint8_t *src, ptrdiff_t src_linesize,
                                    ptrdiff_t bytewidth, int height)
{
  return AVERROR(ENOSYS);
}

#endif

uint32_t av_get_random_seed(void) {	return 0; }

//uint32_t av_gettime(void)
//{
//	return 1331972053200000;
//}
